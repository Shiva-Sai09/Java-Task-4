1. Difference between FileReader and BufferedReader (Theory)
FileReader is a basic class used to read characters from a file one at a time. BufferedReader wraps around a FileReader and reads larger chunks of data into a buffer, making it more efficient and allowing line-by-line reading using readLine().

2. What is try-with-resources?
try-with-resources is a Java feature that automatically closes resources (like files, streams) after the try block finishes, without needing a finally block. Any class used must implement the AutoCloseable interface.

3. How to handle IOException?
IOException can be handled using a try-catch block. Place the file operations inside the try block and catch the IOException to display an error message or take corrective action.

4. What are checked and unchecked exceptions?
Checked exceptions are errors that the compiler forces you to handle, such as IOException and SQLException. Unchecked exceptions are runtime errors like NullPointerException or ArrayIndexOutOfBoundsException that occur during program execution and are not checked at compile time.

5. How does file writing work in Java?
File writing in Java uses classes like FileWriter or BufferedWriter. These classes convert data into characters and store them in a file. The data can be written in append mode (add to file) or overwrite mode (replace content).

6. What is the difference between append and overwrite mode?
In append mode, new data is added to the existing file content without deleting it. In overwrite mode, the old content is erased, and only the new data remains.

7. What is exception propagation?
Exception propagation is the process of passing an exception from the method where it occurred to the calling method until it is caught by a catch block or the program terminates.

8. How to log exceptions?
Exceptions can be logged using logging frameworks like java.util.logging, Log4j, or SLF4J. These logs can be saved to a file or displayed on the console for debugging and monitoring.

9. What is a stack trace?
A stack trace is a report that shows the sequence of method calls leading to an exception. It helps in identifying where and why the error occurred in the program.

10. When to use finally block?
The finally block is used when you have cleanup code that must run whether or not an exception occurs, such as closing a file, releasing database connections, or freeing resources.