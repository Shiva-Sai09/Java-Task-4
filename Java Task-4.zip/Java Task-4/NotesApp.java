import java.io.*;
import java.util.Scanner;

public class NotesApp {
    private static final String FILE_NAME = "notes.txt";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n=== Notes App ===");
            System.out.println("1. Write Notes");
            System.out.println("2. Read Notes");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    writeNotes(sc);
                    break;
                case 2:
                    readNotes();
                    break;
                case 3:
                    System.out.println("Exiting... Bye!");
                    break;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 3);

        sc.close();
    }

    private static void writeNotes(Scanner sc) {
        try (FileWriter fw = new FileWriter(FILE_NAME, true)) { // append mode
            System.out.println("Enter your note (type 'END' to finish):");
            while (true) {
                String line = sc.nextLine();
                if (line.equalsIgnoreCase("END")) break;
                fw.write(line + System.lineSeparator());
            }
            System.out.println("✅ Notes saved successfully!");
        } catch (IOException e) {
            System.out.println("❌ Error writing notes: " + e.getMessage());
        }
    }

    private static void readNotes() {
        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            System.out.println("\n--- Saved Notes ---");
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            System.out.println("❌ No notes found! Please write notes first.");
        } catch (IOException e) {
            System.out.println("❌ Error reading notes: " + e.getMessage());
        }
    }
}
